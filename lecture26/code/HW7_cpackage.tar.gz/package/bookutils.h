#ifndef _MYBOOKUTILS_H
#define _MYBOOKUTILS_H

#include <stdio.h>
void mygetline(FILE* stream, char line[], char delim, int max);
#endif

