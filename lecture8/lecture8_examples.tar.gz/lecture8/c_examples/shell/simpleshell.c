/*fork_exec_wait.c*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

void mygetline(char line[], char delim, int max)
{
   int ch;
   int count = 0;
   while(  ((ch = fgetc(stdin)) != EOF) && ch != delim && count < max)
       line[count++] = ch;
   line[count] = '\0';
}

int main(int argc, char * argv[])
{
  char * ls_args[3] = { "ls", "-l", NULL} ;
  const int max = 200;
  char line[max];

  pid_t c_pid, pid;
  int status;

  while(1)
  {
     printf("mikeShell$");
     mygetline(line, '\n', max-1);

     c_pid = fork();

      if (c_pid == 0)
      {
        //CHILD 
        execvp(line, ls_args);
        //only get here if exec failed                                                  perror("execve failed");
      }
      else if (c_pid > 0)
      {
        // PARENT 
        if( (pid = wait(&status)) < 0)
	{
           perror("wait");
           _exit(1);
        }

        printf("Parent: finished\n");
      }
      else
      {
         perror("fork failed");
         _exit(1);
      }
  }

  return 0; //return success
}
