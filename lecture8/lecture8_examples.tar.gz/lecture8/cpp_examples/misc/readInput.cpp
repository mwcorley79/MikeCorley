#include <iostream>

int main()
{
   std::string name;
   int age;
   std::cout << "Enter name and age " << std::endl;
   std::cin >> name >> age;

   std::cout << "You entered: " << name << " and " << age << std::endl;
   return 0;
 }


