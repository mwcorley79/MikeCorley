#include<iostream>
#include "books.h"


char DisplayMenu()
{
   std::string input;
   std::cout << "\n\nA - Add a Book\n";
   std::cout << "L - List Books\n";
   std::cout << "R - Read from file\n";
   std::cout << "Q - Quit\n";
   std::cout << "Enter Choice: -> ";
   getline(std::cin, input);
   return std::tolower(input[0]);
}

void ReadFile(const std::string& filename, BookCollection& collection)
{
  std::ifstream f(filename.c_str());
  if(f.is_open())
  {
    std::cout << "\n Reading Books records from: " << filename << "\n";
    while(f.good())
    {
      collection.ReadCollectionItems(f);
    }
    
    f.close();
    std::cout << "complete\n";
  }
  else
    std::cout << "\n Can't open file: " << filename << std::endl;
}


void ProcessMenu(BookCollection& collection)
{
   char ch = DisplayMenu();
   while(ch != 'q')
   {
     switch(ch)
     {
       case 'a':
         collection.ReadCollectionItems(std::cin);
         {
	       std::cout << "Success, Collection contains: " << collection.CollectionLength() << " books" << std::endl;
         }
       break;

       case 'l':
       case 'L':
          std::cout << "\nThe collection list is:" <<" \n";
          collection.ListCollection();
       break;

       case 'r':
       {
          std::string filename;
	      std::cout << "\nPlease enter a filename: ";
	      getline(std::cin, filename);
          ReadFile(filename, collection);
       }
       break;

       default:
          if(ch != 'q')
             std::cerr << "Invalid option:" << ch << std::endl;
     }

     ch = DisplayMenu();
   }      
}


int main()
{
   BookCollection collection;
   ProcessMenu(collection);
   return 0;
}
