#include "libs.h"
#include <iostream>

extern "C" {

void say1(){
  std::cout << "say1" << std::endl;
}

}
