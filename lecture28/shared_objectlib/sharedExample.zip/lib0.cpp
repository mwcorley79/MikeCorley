#include "libs.h"
#include <iostream>

extern "C" {

void say0(){
  std::cout << "say0" << std::endl;
}

}
