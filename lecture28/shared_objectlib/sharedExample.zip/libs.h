#ifndef LIBS_H
#define LIBS_H

extern "C" {

void say0();
void say1();

}

#endif
