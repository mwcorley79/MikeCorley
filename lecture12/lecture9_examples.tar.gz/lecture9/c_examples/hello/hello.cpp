#include<iostream>  /* notice no .h in the standard c++ headers */
using namespace std;

/* execution of C/C++ programs begins in the main() method */
int main()
{
  std::cout << "Hello CSE384" << std::endl;
  return 0;
}
