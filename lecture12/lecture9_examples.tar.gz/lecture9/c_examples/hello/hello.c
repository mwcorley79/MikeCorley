/* 
  #include -  preprocessor directive.
  tells the preprocessor to include library headers 
  for access to library data and functions
*/ 

/* 
   #include  the standard I/O library: 
   access to functions: printf etc. 
*/

#include<stdio.h> 

/* execution of C/C++ programs begins in the main() method */
int main()
{
  printf("Hello CSE384\n");
  return 0;
}
