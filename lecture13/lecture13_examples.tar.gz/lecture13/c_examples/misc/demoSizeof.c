//https://www.geeksforgeeks.org/sizeof-operator-c/
#include <stdio.h> 
int main() 
{ 
    printf("%lu\n", sizeof(char)); 
    printf("%lu\n", sizeof(long int)); 
    printf("%lu\n", sizeof(float)); 
    printf("%lu\n", sizeof(double)); 
    return 0; 
} 

