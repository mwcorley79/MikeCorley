#!/bin/bash

# NOTE: The square brackets ([]) in the if statement above are 
# actually a reference to the command test
# man test to see list of operators
# Source: https://ryanstutorials.net/bash-scripting-tutorial/bash-if-statements.php

num=1
if [ $num -eq 001 ]
  then
    echo Hey that\'s a large number.
    pwd
fi


if [ $num = 001 ]
  then
    echo Hey that\'s a large number.
    pwd
  else
    echo Hey is that even a number?
fi


#string based comparison
test 001 = 1
echo $?  # $? holds the exit status if the previous command, will be 0 on success and 
         # 1  on error

# numerical comparsion
test 001 -eq 1
echo $?  # command exist status -> was the test successful? 

# does the file exists, and greater than 0 ?
touch myfile
test -s myfile
echo $?

ls /etc > myfile
test -s myfile
echo $?

if [ -f "myfile" ] && [ -s "myfile" ]
then
  echo myfile exists and is greater than 0 
fi

#arithmetic expansion
num=100
if (( $num % 2 == 0 ))
then
   echo And $num is also an even number $?
else
   echo And $num is also an odd number: $?
fi


