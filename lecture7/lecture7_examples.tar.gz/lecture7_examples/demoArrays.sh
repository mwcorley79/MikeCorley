#!/bin/bash

distro=("redhat" "debian" "gentoo" "ubuntu" "mint")
# get length of $distro array

len=${#distro[@]}
echo Array len is: $len

## Use bash for loop
for (( i=0; i<$len; i++ )); 
do 
  echo "${distro[$i]}" ; 
done
