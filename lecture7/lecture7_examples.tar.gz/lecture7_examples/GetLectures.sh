#!/bin/bash

echo "Capturing lectures.."
count=1
for url in $(cat lectures.txt); do
  outputName="lecture_"$count
  count=$((count + 1))
  echo "curl $url > $outputName.html"
  curl $url > $outputName.html 
done
echo "Got em!
