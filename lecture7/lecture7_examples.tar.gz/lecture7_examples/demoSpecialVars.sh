#!/bin/bash


echo Name of the script: $0
echo Number of arguments supplied: $#

echo All arguments supplied: $@
echo All arguments supplied: $*

output=$(ls -1 $1)
#echo $output
echo Exit status? : $?
echo Exit status? : $?
echo Number of arguments supplied: $@
echo Process id: $$
echo Current Line: $LINENO

echo All: $0, $1, $2, $3


