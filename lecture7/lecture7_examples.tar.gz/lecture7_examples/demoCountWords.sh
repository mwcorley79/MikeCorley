#!/bin/bash

# a note about square brackets in "if" statements:
# The square brackets ([]) in the if statement above are actually 
# a reference to the command test. This means that all of the operators 
# that test allows may be used here as well. Look up the man page for test 
# to see all of the possible operators (there are quite a few) 
# but some of the more common ones are listed below.

# source: https://ryanstutorials.net/bash-scripting-tutorial/bash-if-statements.php

#e.g. test 1 = 01 && echo "yes"
#     echo $?  -- a special variable used to find the return value of the 
#                 last executed command

# test 1 -eq 01 && echo "yes"
# echo $?

function DisplayFiles()
{
  local filename=$1
  if [ -f "$filename" ]; then
    echo $filename
  fi
}

function DisplayWords()
{
  if [ -f "$filename" ]; then
       count=0
       for word in $(cat $filename); do
	   count=$((count + 1))
           echo "Word $count :-> $word"
       done
  fi 
}

function DisplayCharacters()
{
   wordVar="$1"
   echo "Word 1 $wordVar contains $(echo -n $wordVar | wc -c) characters"
}

function DisplayWordCount()
{
  local filename=$1
  if [ -f "$filename" ]; then
       count=0
       for word in $(cat $filename); do
           count=$((count + 1))
           echo "Word $count ($word) contains $(echo -n $word | wc -c) characters"
       done
  fi
}


# S@ expands all of the arguments supplied
for filename in "$@"; do
      DisplayFiles $filename
      sleep 5
      DisplayWords $filename
      sleep 5
      DisplayCharacters "mike"
      sleep 5 
      DisplayWordCount $filename
done
