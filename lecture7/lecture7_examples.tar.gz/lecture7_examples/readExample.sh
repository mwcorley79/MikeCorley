#!/bin/bash

echo -n "Enter some text: "
read text
echo "You entered: $text"

printf '%s\n' "Enter some text: "
read text
echo "You entered: $text"
