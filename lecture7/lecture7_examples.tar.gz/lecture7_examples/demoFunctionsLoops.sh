#!/bin/bash

function demoWhileLoop
{
  counter=1
  while [ $counter -le $1 ]
  do
     echo $counter
     ((counter++))
  done
  echo All done
}


function demoUntilLoop
{
  # Basic until loops  execute the commands within it until the test becomes true
  local counter=1
  until [ $counter -gt $1 ]
  do
     echo $counter
     ((counter++))
  done
  echo All done
}


function demoRangeforLoop
{
  for value in {a..f}
    do
      echo $value
    done
  echo All done
}

function CheckPII
{
   file_content=$(java -jar tika/tika-app-1.23.jar -T $file 2> /dev/null)
   echo $file_content > $file.txt
   
   while read F  ; do
       echo Searching PII: $file for PII pattern: "$F"
       echo "grep -i -l $F $file.txt" 
       grep -i -l "$F $file.txt"  
   done < match-expressions.txt  
}

function demoforLoop
{
   > output.txt
   for file in $@
   # for file in $1
      do
	if [ -f $file ] && [ ${file: -4} != ".txt" ]
	then
          CheckPII $file
          echo $file
        fi
      done
    echo All done
}

function demoRangeFor()
{
  # Basic range with steps for loop
  for value in {10..0..2}
    do
      echo $value
    done
  echo All done
}

function demoFor()
{
  sentence="CSE384 is a good class with fun topics"
  for word in $sentence; do
     echo $word
  done
}

function max()
{
   return 254
   # Note: return status can be specified by using the return keyword
   # it is assigned to the variable $?. The return statement terminates 
   # the function with the exit status.

   # Source: https://linuxize.com/post/bash-functions/
}

#return a value from a function is to send the value to stdout using echo 

function max2() 
{
  local func_result=254
  echo "$func_result"
  # simulate a return a value from a function by sending the value to stdout using echo 
}
 

echo "Demo While Loop"
demoWhileLoop 5
echo;sleep 2

echo "Demo Until Loop"
demoUntilLoop 3
echo;sleep 3

echo DemoRangeForLoop
demoRangeforLoop
echo;sleep 3

echo DemoRangeForLoop with step 2
demoRangeFor
echo;sleep 3

echo DemoFor
demoFor
echo;sleep 3

echo Demo for loop with function args
demoforLoop $(ls docs/*.*)
#demoforLoop "$(ls ./docs)"
echo;sleep 3

echo "Testing function max() exit status"
max 
echo $? # check exit status

echo "Check max() for a return value??"
maxVal="$(max)" 
echo $maxVal 

echo Simulate function return value by writing to stdout
maxVal="$(max2)"
echo $maxVal

